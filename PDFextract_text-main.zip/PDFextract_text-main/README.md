# PDFextract_text
This is the beta version of PDF Extract, it only extracts text out of user-selected PDF files.
<br>
The full version also handles image extraction and exceptions.
<br>
<br>
![text-Extract](https://user-images.githubusercontent.com/32107652/100146136-497a2300-2e4e-11eb-999c-36c03ab0ecfb.jpg)
<br>
<br>
<b>This App was Created for Learning Purposes</b>
<br>
Please feel free to use whatever you need to help you get a better understanding of Tkinter/PyPdf2/Python
<br>
Also exists in a video tutorial:
<br>
https://youtu.be/itRLRfuL_PQ
<br>
<br>
<b>/starterFiles</b>
<br>
If you are following the video tutorial of this project, please download the 3 starter files
<br>
<b>/finishedProject</b>
<br>
This file contains the full beta app, you can download the files and run it inside your terminal.
<br>
If you do not require a tutorial, and just want to have a peak at the code.
<br>
<br>
<b>Author:</b> Mariya Sha
<br>
<b>LinkedIn:</b> www.linkedin.com/in/mariyasha888
<br>
<b>Youtube:</b> www.youtube.com/PythonSimplified
<br>
<b>Instagram:</b> www.instagram.com/mariyasha888
